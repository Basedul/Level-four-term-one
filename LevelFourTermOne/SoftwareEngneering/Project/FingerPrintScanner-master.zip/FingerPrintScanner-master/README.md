# Finger Print Scanner
Arduino Fingerprint Sensor / Java Frontend
Project for our course Software Engineering. Two parts of code not combined yet.
The first part interacts with our finger print scanner for the connection with a Java programm and store finger prints in the devices internal storage.
The second part is a Java programm that interacts with MySQL Workbench that stores administratos of the system and customers and when you try to sing in it identifies if you are an admin or a customer and creates different interfaces for each group.
The idea of the project that we have to finish is instead of storing passwords store the finger prints of the users and the identification will be based on the fingerprints.
