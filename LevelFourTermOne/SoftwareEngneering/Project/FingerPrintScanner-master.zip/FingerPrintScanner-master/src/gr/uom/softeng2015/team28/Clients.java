package gr.uom.softeng2015.team28;
import java.util.Date;


public class Clients extends User{
	
	public Clients(String name,String surname,Date date,int code){
		super(name,surname,date,code);
	}
	
}
