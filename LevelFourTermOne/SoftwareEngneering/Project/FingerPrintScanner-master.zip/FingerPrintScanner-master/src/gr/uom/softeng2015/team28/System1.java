package gr.uom.softeng2015.team28;

public abstract class System1 {
	
	public static void CompareCode(User u,int i){
		if(u.getFinger_print()==i){
			System.out.println("Swstos kwdikos");
		}
		else{
			System.out.println("Go fuck yourself");
		}
	}
}
