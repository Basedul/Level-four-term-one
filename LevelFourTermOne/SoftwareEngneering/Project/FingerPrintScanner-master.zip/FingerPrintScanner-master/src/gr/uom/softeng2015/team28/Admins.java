package gr.uom.softeng2015.team28;
import java.util.Date;


public class Admins extends User{
	
	
	public Admins(String name,String surname,Date date,int code){
		super(name,surname,date,code);
	}

}
