The file ZFM-20_Fingerprint_Module.pdf is an automatic translation of the original Chinese datasheet, as performed by Google Translate. We provide it as a courtesy only, and have not reviewed the translation for accuracy or completeness.

Original datasheet available here:
http://www.adafruit.com/datasheets/DY001fingerprint.pdf

-------
R.D. Lesniak, Oct. 31, 2012